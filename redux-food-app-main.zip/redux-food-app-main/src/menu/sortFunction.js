
export const sortFunction = (array)=>{

    // for(let i=0;i<array.length;i++)
    // {
    //   if(array[i].price>array[i+1].price)
    //   {
    //       let temp=0;
    //       temp=array[i+1];
    //       array[i+1]=temp;
    //       array[i]=temp;
    //   }
    // }
    console.log(array[0].price);
    
}