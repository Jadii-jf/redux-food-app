export const AREA ='AREA';
export const CATEGOGRY = 'CATEGORY';
export const COUNTER = 'COUNTER';
export const CART = 'CART';
