import React from 'react'

export const FoodItem = (props) => {
    return (
        <div>
            
        </div>
    )
}
